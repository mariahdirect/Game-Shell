/*
 Name: Maria H.
 A simple shell for searching and executing games
 */

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>

#define MAX 128

// Error message used by the program
char *err = "An error has occurred\n";

// Prints the error message
void error(void) {
    write(2, err, strlen(err));
}

// Checks if the path is a directory
int isdir(char *p) {
    struct stat s;
    return stat(p, &s) == 0 && S_ISDIR(s.st_mode);
}

// Makes a full path using the directory and file name
char *path(char *d, char *n) {
    char *p = malloc(strlen(d) + strlen(n) + 2);

    if (p)
        sprintf(p, "%s/%s", d, n);

    return p;
}

// Used to sort the file names
int cmp(const void *a, const void *b) {
    return strcmp(*(char **)a, *(char **)b);
}

// Lists the games in alphabetical order
void ls(char *dir) {
    DIR *d = opendir(dir);
    struct dirent *e;
    char *n[MAX], *p;
    int c = 0, i;
    struct stat s;

    // Open the game directory
    if (!d) {
        error();
        return;
    }

    // Get the regular files from the directory
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, ".."))
            continue;

        p = path(dir, e->d_name);

        if (p && !stat(p, &s) && S_ISREG(s.st_mode))
            n[c++] = strdup(e->d_name);

        free(p);

        if (c >= MAX - 1)
            break;
    }

    closedir(d);

    // Sort the game names
    qsort(n, c, sizeof(char *), cmp);

    // Run each game with --help and save the output
    for (i = 0; i < c; i++) {
        char tmp[100];
        sprintf(tmp, "/tmp/gsh_help_%d_%d", (int)getpid(), i);

        int f = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0600);
        pid_t pid = fork();
        p = path(dir, n[i]);

        if (pid == 0) {
            char *a[] = {n[i], "--help", NULL};

            // Send the help output to the temp file
            dup2(f, 1);
            close(f);

            execv(p, a);
            exit(1);
        }

        close(f);

        // Wait for the game to finish
        int status;
        waitpid(pid, &status, 0);

        // Read the help message
        if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            f = open(tmp, O_RDONLY);

            char b[4096];
            int x = read(f, b, 4095);
            close(f);

            if (x > 0) {
                b[x] = 0;
                printf("%s: %s", n[i], b);

                if (b[x - 1] != '\n')
                    printf("\n");
            } else {
                printf("%s: (empty)\n", n[i]);
            }
        } else {
            printf("%s: (empty)\n", n[i]);
        }

        // Delete the temp file
        unlink(tmp);

        free(p);
        free(n[i]);
    }
}

// Runs a game using a child process
void run(char *dir, char **a, char *in) {
    pid_t p = fork();

    if (p == 0) {

        // Handle input redirection
        if (in) {
            int f = open(in, O_RDONLY);

            if (f < 0) {
                error();
                exit(1);
            }

            dup2(f, 0);
            close(f);
        }

        // Set the game directory for execvp
        setenv("PATH", dir, 1);

        // Run the game
        execvp(a[0], a);

        error();
        exit(1);
    }

    // Wait for the game to finish
    waitpid(p, NULL, 0);
}

// Splits the command into arguments and checks redirection
int parse(char *l, char **a, char **in) {
    char *t = strtok(l, " \t\n");
    int n = 0;

    *in = NULL;

    while (t) {
        if (!strcmp(t, "<")) {

            // Make sure there is only one input file
            if (*in || !(t = strtok(NULL, " \t\n")))
                return -1;

            *in = t;
        } else {

            // Do not allow arguments after the input file
            if (*in || n >= MAX - 1)
                return -1;

            a[n++] = t;
        }

        t = strtok(NULL, " \t\n");
    }

    // End the argument list
    a[n] = NULL;

    return n;
}

// Main function for the shell
// Checks the directory and runs the shell loop
int main(int c, char **v) {
    char *dir, *line = NULL, *in;
    char *a[MAX];
    size_t z = 0;
    int n;

    // Check that one valid directory was given
    if (c != 2 || !isdir(v[1])) {
        error();
        return 1;
    }

    dir = strdup(v[1]);

    // Keep running until exit is entered
    while (1) {

        // Print the shell prompt
        printf("gsh> ");
        fflush(stdout);

        // Get the user's command
        if (getline(&line, &z, stdin) < 0)
            break;

        // Parse the command
        n = parse(line, a, &in);

        if (n < 0) {
            error();
            continue;
        }

        // Ignore empty lines
        if (!n)
            continue;

        // Exit command
        if (!strcmp(a[0], "exit")) {
            if (n != 1 || in) {
                error();
                continue;
            }

            break;
        }

        // Change the game directory
        if (!strcmp(a[0], "path")) {
            if (n != 2 || in || !isdir(a[1])) {
                error();
                continue;
            }

            free(dir);
            dir = strdup(a[1]);
            continue;
        }

        // List the games
        if (!strcmp(a[0], "ls")) {
            if (n != 1 || in) {
                error();
                continue;
            }

            ls(dir);
            continue;
        }

        // Run a game
        run(dir, a, in);
    }

    // Frees memory before ending
    free(dir);
    free(line);

    return 0;
}